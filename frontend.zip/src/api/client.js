/**
 * Backend API client.
 *
 * Base URL comes from REACT_APP_API_URL, a build-time env var (CRA only
 * exposes vars prefixed REACT_APP_). Set this in Netlify's site settings ->
 * Environment variables, pointing at the Northflank service URL, e.g.
 * https://sport--backend-api--7kcwxz9xblx5.code.run
 *
 * Falls back to that same Northflank URL for local dev convenience — override
 * it locally via a .env.local file if you're running the backend elsewhere
 * (e.g. http://localhost:8080).
 */
const API_BASE_URL =
  process.env.REACT_APP_API_URL || 'https://sport--backend-api--7kcwxz9xblx5.code.run';

async function request(path) {
  const res = await fetch(`${API_BASE_URL}${path}`);
  if (!res.ok) {
    const error = new Error(`Request to ${path} failed with status ${res.status}`);
    error.status = res.status;
    try {
      error.body = await res.json();
    } catch {
      // Response wasn't JSON — leave error.body undefined, error.status is
      // still meaningful on its own.
    }
    throw error;
  }
  return res.json();
}

export function getOverview() {
  return request('/api/overview');

}

export function getStatistics({ view, season, sessionId } = {}) {
  const params = new URLSearchParams();
  if (view) params.set('view', view);
  if (season != null) params.set('season', season);
  if (sessionId) params.set('sessionId', sessionId);
  const query = params.toString();
  return request(`/api/statistics${query ? `?${query}` : ''}`);
}

export function getFixtures() {
  return request('/api/fixtures');
}

export function getFixtureEvents(sessionId) {
  return request(`/api/fixtures/${sessionId}/events`);
}

export function getTimeTravelContext(sessionId) {
  const params = new URLSearchParams();
  if (sessionId) params.set('sessionId', sessionId);
  const query = params.toString();
  return request(`/api/timetravel/context${query ? `?${query}` : ''}`);
}

export function getTimeTravelChangelog(entryId) {
  return request(`/api/timetravel/changelog?entryId=${entryId}`);
}

export function getTimeTravelAsOf({ sessionId, entryId, date }) {
  const params = new URLSearchParams({ sessionId, entryId, date });
  return request(`/api/timetravel/asof?${params.toString()}`);
}

export function getPopularVideos() {
  return request('/api/videos/popular');
}

export function getLiveVideo() {
  return request('/api/watch-live');
}

export function getTeams({ limit, offset } = {}) {
  const params = new URLSearchParams();
  if (limit != null) params.set('limit', String(limit));
  if (offset != null) params.set('offset', String(offset));
  const query = params.toString();
  return request(`/api/teams${query ? `?${query}` : ''}`);
}

export function getTeam(id) {
  return request(`/api/teams/${id}`);
}

export function getDrivers({ limit, offset } = {}) {
  const params = new URLSearchParams();
  if (limit != null) params.set('limit', String(limit));
  if (offset != null) params.set('offset', String(offset));
  const query = params.toString();
  return request(`/api/drivers${query ? `?${query}` : ''}`);
}

export function getDriver(id) {
  return request(`/api/drivers/${id}`);
}

// Remote headshots/logos are routed through the backend's caching image proxy
// so the browser reuses one immutable, cached copy per asset.
export function getCachedImageUrl(source) {
  return `${API_BASE_URL}/api/images?source=${encodeURIComponent(source)}`;
}

// A driver's headshot once it's been persisted server-side (Firestore) —
// same URL forever for a given driver, no source param needed.
export function getDriverImageUrl(driverId) {
  return `${API_BASE_URL}/api/drivers/${driverId}/image`;
}

// Fetches one replay state or a short playback buffer.
export function getWatchLiveState({ videoSeconds, bufferSeconds } = {}) {
  const params = new URLSearchParams({ videoSeconds: String(videoSeconds) });
  if (bufferSeconds != null) params.set('bufferSeconds', String(bufferSeconds));
  return request(`/api/watch-live/state?${params.toString()}`);
}

// Real track outline derived from one driver's actual location telemetry —
// see deriveTrackShape() in the backend for how this is picked.
export function getTrackShape() {
  return request('/api/watch-live/track-shape');
}